#include "Command_Factory.h"

Command_Factory::Command_Factory()
{}

Command_Factory::~Command_Factory()
{}
