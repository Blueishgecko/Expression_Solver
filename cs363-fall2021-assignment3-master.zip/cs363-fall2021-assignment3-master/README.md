# cs363-fall2021-assignment3


## Code Explanation

Code compiles and asks user for a calculation. Unfortunately, without being
able to implement the wrapper correctly, this is where the program ends. I 
had issues with the program closing on empty_exception with all of my tries 
at the wrapper. It's possible that my stack class was not working properly. Either way, 
I was never able to get the program to do the actual calculations. I feel as if the code
is sound outside of the wrapper. 

Mod_Command.h was for some reason not wanting to be seen by the compiler. After hours of
checking these files, I don't really see where the issue with Mod_Command.h is. 


Only had 1 comment from inital submission, which I addressed in Divide_Command.cpp

